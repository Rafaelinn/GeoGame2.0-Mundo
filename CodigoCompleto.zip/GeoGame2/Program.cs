﻿using System;

namespace GeoGame2
{
    class Program
    {
        static void Main(string[] args)
        {
            Game geoGame = new Game("");
        }
    }
}
