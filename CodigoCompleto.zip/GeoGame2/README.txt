Desenvolvido por Rafael Durand

Para escolher o continente, no Program.cs, na linha 9.
-Game geoGame = new Game("");-

digite entre |"mundo"|"america"|"europa"|"asia"|"africa"|"oceania"| dentro das aspas,
para escolher o mundo inteiro ou um continente, no construtor.

**É necessário escolher um desses acima para o jogo funcionar.

**Nas respostas digite como por exemplo: "colombia","estados unidos","bolivia".
Sem acentos.

** = Importante